import bpy

class ARVEHICLES_PT_panel(bpy.types.Panel):
    bl_label = "AR Vehicles Enhanced"
    bl_idname = "ARVEHICLES_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'AR Vehicles'
    
    def draw(self, context):
        layout = self.layout
        # Collision
        box = layout.box()
        box.label(text="Collision", icon='MESH_CUBE')
        
        row = box.row(align=True)
        row.operator("arvehicles.create_ucx_collision", text="UCX Physics", icon='MESH_CUBE')
        row.operator("arvehicles.create_firegeo_collision", text="FireGeo", icon='MESH_ICOSPHERE')
        
        row = box.row(align=True)
        row.operator("arvehicles.create_wheel_collisions", text="Wheel Collision", icon='MESH_CYLINDER')
        row.operator("arvehicles.create_center_of_mass", text="Center of Mass", icon='EMPTY_SINGLE_ARROW')
             
        # Component Separation
        box = layout.box()
        box.label(text="Component Separation", icon='MOD_BUILD')
        box.operator("arvehicles.separate_components", text="Separate Component", icon='UNLINKED')
        
        col = box.column(align=True)
        col.separator()
        col.label(text="Add to Existing Objects:")
        col.operator("arvehicles.add_to_object", text="Add Bone/Socket to Object", icon='EMPTY_ARROWS')
        
   
        # Attachment Points
        box = layout.box()
        box.label(text="Attachment Points", icon='EMPTY_DATA')
        
        col = box.column(align=True)
        col.label(text="Create Sockets:")
        
        op = col.operator("arvehicles.create_socket", text="Add Socket")
        op.socket_type = 'custom'
        
        # Mesh Tools
        box = layout.box()
        box.label(text="Mesh Tools", icon='EDITMODE_HLT')
        
        row = box.row(align=True)
        row.operator("arvehicles.cleanup_mesh", text="Cleanup Mesh", icon='BRUSH_DATA')
        row.operator("arvehicles.create_lods", text="Create LODs", icon='MOD_DECIM')
        
        # Preparation
        box = layout.box()
        box.label(text="Preparation", icon='ORIENTATION_VIEW')
        box.operator("arvehicles.center_vehicle", text="Center Vehicle", icon='PIVOT_BOUNDBOX')
        
        # Rigging
        box = layout.box()
        box.label(text="Rigging", icon='ARMATURE_DATA')
        
        col = box.column(align=True)
        col.operator("arvehicles.create_armature", text="Create Vehicle Armature", icon='ARMATURE_DATA')
        
        col.separator()
        col.label(text="Add Bones:")
        col.operator("arvehicles.create_bone", text="Add Bone").bone_type = 'custom'
        
        col.separator()
        col.label(text="Bone Hierarchy:")
        col.operator("arvehicles.parent_bones", text="Parent Bones", icon='CONSTRAINT_BONE')
        col.operator("arvehicles.align_bones_direction", text="Align Bone Directions", icon='ORIENTATION_GLOBAL')
        col.operator("arvehicles.create_vertex_group", text="Assign to Bone", icon='WPAINT_HLT')
        
        col.separator()
        
        col.separator()
        col.label(text="Parenting:")
        row = col.row(align=True)
        row.operator("arvehicles.parent_to_armature", text="Parent Meshes")
        row.operator("arvehicles.parent_empties", text="Parent Empties")
        
        # Two-Phase Preset Manager
        box = layout.box()
        box.label(text="Two-Phase Preset Manager", icon='PRESET')
        
        col = box.column(align=True)
        col.operator("arvehicles.manage_presets", text="Create/Edit Preset", icon='PLUS')
        
        row = col.row(align=True)
        row.operator("arvehicles.preset_separation", text="Separate Action", icon='LOOP_FORWARDS')
        row.operator("arvehicles.skip_preset_item", text="Skip", icon='FORWARD')
        
        row = col.row(align=True)
        row.operator("arvehicles.reset_preset", text="Reset", icon='FILE_REFRESH')
        
        # Show current preset status
        scene = context.scene
        if "arvehicles_active_preset" in scene:
            preset_name = scene["arvehicles_active_preset"]
            preset_prefix = f"arvehicles_preset_{preset_name}_"
            
            count_key = f"{preset_prefix}count"
            if count_key in scene:
                preset_count = scene[count_key]
                current_phase = scene.get(f"{preset_prefix}phase", "bones")
                
                col.separator()
                col.label(text=f"Active: {preset_name}")
                col.label(text=f"Phase: {current_phase.title()}")
                
                if current_phase == "bones":
                    bone_index = scene.get(f"{preset_prefix}bone_index", 0)
                    if bone_index < preset_count:
                        bone_key = f"{preset_prefix}bone_{bone_index}"
                        if bone_key in scene:
                            next_bone = scene[bone_key]
                            col.label(text=f"Next: {next_bone}")
                            col.label(text=f"Mesh: Mesh_{next_bone}")
                            col.label(text=f"Progress: {bone_index + 1}/{preset_count}")
                        else:
                            col.label(text="Error: Bone data missing")
                    else:
                        col.label(text="Ready for socket phase!")
                else:
                    socket_index = scene.get(f"{preset_prefix}socket_index", 0)
                    if socket_index < preset_count:
                        socket_key = f"{preset_prefix}socket_{socket_index}"
                        if socket_key in scene:
                            next_socket = scene[socket_key]
                            col.label(text=f"Next: {next_socket}")
                            col.label(text=f"Progress: {socket_index + 1}/{preset_count}")
                        else:
                            col.label(text="Error: Socket data missing")
                    else:
                        col.label(text="All complete!")
        else:
            col.separator()
            col.label(text="No active preset")
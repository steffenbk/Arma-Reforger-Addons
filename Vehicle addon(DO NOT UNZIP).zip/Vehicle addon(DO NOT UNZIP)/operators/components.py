# ============================================================================
# IMPORTS AND CLASS DEFINITION
# ============================================================================
import bpy
import bmesh
import mathutils
from mathutils import Vector
from ..constants import VEHICLE_COMPONENT_TYPES


# ============================================================================
# COMPONENT SEPARATION OPERATOR
# ============================================================================
class ARVEHICLES_OT_separate_components(bpy.types.Operator):
    bl_idname = "arvehicles.separate_components"
    bl_label = "Separate Vehicle Components"
    bl_options = {'REGISTER', 'UNDO'}

    # ============================================================================
    # PROPERTIES
    # ============================================================================
    component_type: bpy.props.EnumProperty(name="Component Type", items=VEHICLE_COMPONENT_TYPES, default='door')
    custom_name: bpy.props.StringProperty(name="Custom Name", default="")

    # Socket properties
    add_socket: bpy.props.BoolProperty(name="Add Socket", default=True)
    custom_socket_name: bpy.props.StringProperty(name="Custom Socket Name", default="")
    set_origin_to_socket: bpy.props.BoolProperty(name="Set Origin to Socket", default=True)
    parent_socket_to_armature: bpy.props.BoolProperty(name="Parent Socket to Armature", default=True)

    # Bone properties
    add_bone: bpy.props.BoolProperty(name="Add Bone", default=False)
    custom_bone_name: bpy.props.StringProperty(name="Custom Bone Name", default="")
    auto_skinning: bpy.props.BoolProperty(name="Auto Skinning", default=True)
    invert_bone_direction: bpy.props.BoolProperty(name="Invert Bone Direction", default=False)

    use_world_direction: bpy.props.BoolProperty(name="Use World Direction", default=False)
    world_direction: bpy.props.EnumProperty(
        name="World Direction",
        items=[
            ('POS_Y', "+Y (Forward)", ""),
            ('NEG_Y', "-Y (Backward)", ""),
            ('POS_X', "+X (Right)", ""),
            ('NEG_X', "-X (Left)", ""),
            ('POS_Z', "+Z (Up)", ""),
            ('NEG_Z', "-Z (Down)", ""),
        ],
        default='POS_Y'
    )
    preserve_angle: bpy.props.BoolProperty(name="Preserve Angle", default=False)

    bone_primary_axis: bpy.props.EnumProperty(
        name="Primary Rotation Axis",
        items=[
            ('Y', "Y Axis (Default)", ""),
            ('X', "X Axis", ""),
            ('Z', "Z Axis", ""),
        ],
        default='Y'
    )
    swap_yz_axes: bpy.props.BoolProperty(name="Swap Y<>Z Axes", default=False)
    align_roll_to_axis: bpy.props.EnumProperty(
        name="Align Roll To",
        items=[
            ('NONE',    "Auto (Roll=0)", ""),
            ('WORLD_Z', "World Z (Up)",  ""),
            ('WORLD_X', "World X",       ""),
            ('WORLD_Y', "World Y",       ""),
        ],
        default='WORLD_Z'
    )
    set_mesh_origin_to_bone: bpy.props.BoolProperty(name="Set Mesh Origin to Bone", default=True)

    # Bone parenting
    parent_to_specific_bone: bpy.props.BoolProperty(
        name="Parent Bone to Specific Bone",
        description="Make the new bone a child of a specific existing bone",
        default=False
    )

    def get_available_bones(self, context):
        items = [('NONE', "v_body (Default)", "Parent to v_body or v_root")]
        for obj in bpy.data.objects:
            if obj.type == 'ARMATURE':
                for bone in obj.data.bones:
                    items.append((bone.name, bone.name, f"Parent new bone to {bone.name}"))
                break
        return items

    target_bone: bpy.props.EnumProperty(
        name="Parent Bone",
        description="Existing bone to parent the new bone to",
        items=get_available_bones
    )

    # Skin to existing bone (used when add_bone is False)
    parent_to_existing_bone: bpy.props.BoolProperty(
        name="Skin to Existing Bone",
        description="Assign all vertices to an existing bone instead of creating a new one",
        default=False
    )

    def get_existing_bones(self, context):
        items = [('NONE', "Select Bone", "No bone selected")]
        for obj in bpy.data.objects:
            if obj.type == 'ARMATURE':
                for bone in obj.data.bones:
                    items.append((bone.name, bone.name, f"Skin mesh to {bone.name}"))
                break
        return items

    existing_target_bone: bpy.props.EnumProperty(
        name="Target Bone",
        description="Existing bone to skin the separated mesh to",
        items=get_existing_bones
    )

    # ============================================================================
    # HELPER METHODS
    # ============================================================================
    def _get_socket_type_for_component(self, component_type):
        component_to_socket = {
            'window': 'window', 'door': 'door', 'hood': 'hood', 'trunk': 'trunk',
            'wheel': 'wheel', 'light': 'light', 'mirror': 'mirror', 'antenna': 'antenna',
            'hatch': 'hatch', 'panel': 'panel', 'seat': 'seat', 'dashboard': 'dashboard',
            'steering_wheel': 'steering_wheel', 'gear_shifter': 'gear_shifter',
            'handbrake': 'handbrake', 'pedal': 'pedal', 'engine': 'engine',
            'exhaust': 'exhaust', 'suspension': 'suspension', 'rotor': 'rotor',
            'landing_gear': 'landing_gear', 'fuel_tank': 'fuel_tank',
            'battery': 'battery', 'radiator': 'radiator',
        }
        return component_to_socket.get(component_type, 'custom')

    def _get_bone_type_for_component(self, component_type):
        component_to_bone = {
            'door': 'v_door_left', 'hood': 'v_hood', 'trunk': 'v_trunk',
            'wheel': 'v_wheel_1', 'steering_wheel': 'v_steering_wheel',
            'gear_shifter': 'v_gearshift', 'handbrake': 'v_handbrake',
            'pedal': 'v_pedal_brake', 'exhaust': 'v_exhaust',
            'suspension': 'v_suspension1', 'rotor': 'v_rotor',
            'landing_gear': 'v_landing_gear', 'antenna': 'v_antenna',
            'mirror': 'v_mirror_left', 'dashboard': 'v_dashboard_arm',
        }
        return component_to_bone.get(component_type, 'custom')

    # ============================================================================
    # EXECUTE
    # ============================================================================
    def execute(self, context):
        if context.mode != 'EDIT_MESH':
            self.report({'ERROR'}, "Must be in Edit Mode with faces selected")
            return {'CANCELLED'}

        mesh = context.active_object.data
        if not mesh.total_face_sel:
            self.report({'ERROR'}, "No faces selected")
            return {'CANCELLED'}

        obj = context.active_object

        # Calculate center and normal from selected faces
        bm = bmesh.from_edit_mesh(mesh)
        selected_faces = [f for f in bm.faces if f.select]

        if not selected_faces:
            self.report({'ERROR'}, "No faces selected")
            return {'CANCELLED'}

        center = Vector((0, 0, 0))
        avg_normal = Vector((0, 0, 0))

        for face in selected_faces:
            center += face.calc_center_median()
            avg_normal += face.normal

        center /= len(selected_faces)
        avg_normal.normalize()

        world_center = obj.matrix_world @ center
        world_normal = obj.matrix_world.to_3x3() @ avg_normal
        world_normal.normalize()

        # Name generation
        prefix_map = {
            'window': "window_", 'door': "door_", 'hood': "hood_", 'trunk': "trunk_",
            'wheel': "wheel_", 'light': "light_", 'mirror': "mirror_", 'seat': "seat_",
            'dashboard': "dashboard_", 'steering_wheel': "steering_wheel_",
            'gear_shifter': "gear_shifter_", 'handbrake': "handbrake_",
            'pedal': "pedal_", 'engine': "engine_", 'exhaust': "exhaust_",
            'suspension': "suspension_", 'rotor': "rotor_", 'landing_gear': "landing_gear_",
            'fuel_tank': "fuel_tank_", 'battery': "battery_", 'radiator': "radiator_",
            'panel': "panel_", 'hatch': "hatch_", 'antenna': "antenna_",
        }

        prefix = prefix_map.get(self.component_type, "component_")
        new_name = self.custom_name if self.custom_name else f"{prefix}{obj.name}"

        # Separate mesh
        bpy.ops.mesh.separate(type='SELECTED')
        bpy.ops.object.mode_set(mode='OBJECT')

        new_obj = context.selected_objects[-1]
        new_obj.name = new_name
        new_obj["component_type"] = self.component_type

        # Set origin to geometry immediately after separation
        bpy.ops.object.select_all(action='DESELECT')
        new_obj.select_set(True)
        context.view_layer.objects.active = new_obj
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')

        # Clean up inherited modifiers and vertex groups
        for mod in list(new_obj.modifiers):
            if mod.type == 'ARMATURE':
                new_obj.modifiers.remove(mod)
        new_obj.vertex_groups.clear()

        # Find armature
        armature = None
        for armature_obj in bpy.data.objects:
            if armature_obj.type == 'ARMATURE':
                armature = armature_obj
                break

        socket = None
        bone = None
        bone_name = None

        socket_type = self._get_socket_type_for_component(self.component_type)
        bone_type   = self._get_bone_type_for_component(self.component_type)

        if self.component_type == 'custom' and self.custom_name:
            socket_type = 'custom'
            bone_type   = 'custom'

        # ============================================================================
        # BONE CREATION
        # ============================================================================
        if self.add_bone:
            if not armature:
                armature_data = bpy.data.armatures.new("Armature")
                armature = bpy.data.objects.new("Armature", armature_data)
                context.collection.objects.link(armature)

                context.view_layer.objects.active = armature
                bpy.ops.object.mode_set(mode='EDIT')

                root_bone = armature.data.edit_bones.new('v_root')
                root_bone.head = (0, 0, 0)
                root_bone.tail = (0, 0.2, 0)
                root_bone.roll = 0.0

                body_bone = armature.data.edit_bones.new('v_body')
                body_bone.head = (0, 0, 0.35)
                body_bone.tail = (0, 0.2, 0.35)
                body_bone.roll = 0.0
                body_bone.parent = root_bone

                bpy.ops.object.mode_set(mode='OBJECT')

            # Generate bone name
            if self.custom_bone_name:
                bone_name = self.custom_bone_name
                if not bone_name.startswith('v_'):
                    bone_name = 'v_' + bone_name
            elif bone_type == 'custom':
                if self.custom_name:
                    bone_name = f"v_{self.custom_name.lower().replace(' ', '_')}"
                else:
                    bone_name = f"v_{new_name.lower().replace(' ', '_')}"
            else:
                bone_name = bone_type
                original_bone_name = bone_name
                counter = 1
                while bone_name in armature.data.bones:
                    bone_name = f"{original_bone_name}_{counter:02d}"
                    counter += 1

            # Create and position bone
            context.view_layer.objects.active = armature
            bpy.ops.object.mode_set(mode='EDIT')

            bone = armature.data.edit_bones.new(bone_name)

            # Set parent based on user choice
            if self.parent_to_specific_bone and self.target_bone != 'NONE':
                if self.target_bone in armature.data.edit_bones:
                    bone.parent = armature.data.edit_bones[self.target_bone]
                    bone.use_connect = False
                else:
                    if 'v_body' in armature.data.edit_bones:
                        bone.parent = armature.data.edit_bones['v_body']
                    elif 'v_root' in armature.data.edit_bones:
                        bone.parent = armature.data.edit_bones['v_root']
            else:
                if 'v_body' in armature.data.edit_bones:
                    bone.parent = armature.data.edit_bones['v_body']
                elif 'v_root' in armature.data.edit_bones:
                    bone.parent = armature.data.edit_bones['v_root']

            # Calculate bone direction
            if self.use_world_direction:
                direction_map = {
                    'POS_Y': Vector((0,  1, 0)),
                    'NEG_Y': Vector((0, -1, 0)),
                    'POS_X': Vector(( 1, 0, 0)),
                    'NEG_X': Vector((-1, 0, 0)),
                    'POS_Z': Vector((0, 0,  1)),
                    'NEG_Z': Vector((0, 0, -1)),
                }
                world_dir = direction_map[self.world_direction]

                if self.preserve_angle:
                    if abs(world_dir.dot(Vector((0, 0, 1)))) < 0.9:
                        up = Vector((0, 0, 1))
                    else:
                        up = Vector((1, 0, 0))

                    right = world_dir.cross(up).normalized()
                    up = right.cross(world_dir).normalized()

                    forward_component = world_normal.dot(world_dir)
                    up_component      = world_normal.dot(up)

                    bone_direction = (world_dir * forward_component + up * up_component).normalized() * 0.2
                else:
                    bone_direction = world_dir * 0.2
            else:
                bone_direction = world_normal * 0.2

            if self.invert_bone_direction:
                bone_direction = -bone_direction

            if self.bone_primary_axis == 'X':
                bone_direction = Vector((bone_direction.y, bone_direction.z, bone_direction.x))
            elif self.bone_primary_axis == 'Z':
                bone_direction = Vector((bone_direction.z, bone_direction.x, bone_direction.y))

            world_head = world_center
            world_tail = world_center + bone_direction

            if self.swap_yz_axes:
                world_head = Vector((world_head.x, world_head.z, world_head.y))
                world_tail = Vector((world_tail.x, world_tail.z, world_tail.y))

            bone.head = world_head
            bone.tail = world_tail

            if self.align_roll_to_axis == 'WORLD_Z':
                bone.align_roll(Vector((0, 0, 1)))
            elif self.align_roll_to_axis == 'WORLD_X':
                bone.align_roll(Vector((1, 0, 0)))
            elif self.align_roll_to_axis == 'WORLD_Y':
                bone.align_roll(Vector((0, 1, 0)))
            else:
                bone.roll = 0.0

            bpy.ops.object.mode_set(mode='OBJECT')

            # Set mesh origin to bone head
            if self.set_mesh_origin_to_bone:
                bpy.ops.object.select_all(action='DESELECT')
                new_obj.select_set(True)
                context.view_layer.objects.active = new_obj

                cursor_location = context.scene.cursor.location.copy()
                context.scene.cursor.location = world_center
                bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
                context.scene.cursor.location = cursor_location

            # Auto skinning
            if self.auto_skinning:
                bpy.ops.object.select_all(action='DESELECT')
                new_obj.select_set(True)
                context.view_layer.objects.active = new_obj

                vertex_group = new_obj.vertex_groups.new(name=bone_name)

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                new_obj.vertex_groups.active = vertex_group
                bpy.ops.object.vertex_group_assign()
                bpy.ops.object.mode_set(mode='OBJECT')

                armature_mod = new_obj.modifiers.new(name="Armature", type='ARMATURE')
                armature_mod.object = armature

                self.report({'INFO'}, f"Setup skinning for '{new_name}' to bone '{bone_name}'")

        # ============================================================================
        # SKIN TO EXISTING BONE (when add_bone is False)
        # ============================================================================
        elif self.parent_to_existing_bone and self.existing_target_bone != 'NONE':
            if armature:
                if self.existing_target_bone in armature.data.bones:
                    bpy.ops.object.select_all(action='DESELECT')
                    new_obj.select_set(True)
                    context.view_layer.objects.active = new_obj

                    for mod in list(new_obj.modifiers):
                        if mod.type == 'ARMATURE':
                            new_obj.modifiers.remove(mod)
                    new_obj.vertex_groups.clear()

                    vertex_group = new_obj.vertex_groups.new(name=self.existing_target_bone)

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.mesh.select_all(action='SELECT')
                    new_obj.vertex_groups.active = vertex_group
                    bpy.ops.object.vertex_group_assign()
                    bpy.ops.object.mode_set(mode='OBJECT')

                    armature_mod = new_obj.modifiers.new(name="Armature", type='ARMATURE')
                    armature_mod.object = armature

                    self.report({'INFO'}, f"Skinned '{new_name}' to existing bone '{self.existing_target_bone}'")
                else:
                    self.report({'WARNING'}, f"Bone '{self.existing_target_bone}' not found in armature")
            else:
                self.report({'WARNING'}, "No armature found - cannot skin to existing bone")

        # ============================================================================
        # SOCKET CREATION
        # ============================================================================
        if self.add_socket:
            if self.custom_socket_name:
                socket_name = self.custom_socket_name
            elif socket_type == 'custom' and self.custom_name:
                socket_name = f"Socket_{self.custom_name.replace(' ', '_').title()}"
            else:
                socket_name = f"Socket_{socket_type.replace('_', ' ').title().replace(' ', '_')}"
                existing_sockets = [o for o in bpy.data.objects if socket_name in o.name]
                if existing_sockets:
                    socket_name = f"{socket_name}_{len(existing_sockets) + 1:02d}"

            socket = bpy.data.objects.new(socket_name, None)
            socket.empty_display_type = 'ARROWS'
            socket.empty_display_size = 0.15
            socket.location = world_center
            context.collection.objects.link(socket)

            socket["socket_type"]   = socket_type
            socket["attached_part"] = new_obj.name
            socket["vehicle_part"]  = "attachment_point"

            if armature and self.parent_socket_to_armature:
                socket.parent = armature
                socket.parent_type = 'OBJECT'

        # Set origin to socket position
        if self.add_socket and self.set_origin_to_socket and socket is not None:
            bpy.ops.object.select_all(action='DESELECT')
            new_obj.select_set(True)
            context.view_layer.objects.active = new_obj

            cursor_location = context.scene.cursor.location.copy()
            context.scene.cursor.location = socket.location
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            context.scene.cursor.location = cursor_location

        # Final selection
        bpy.ops.object.select_all(action='DESELECT')
        new_obj.select_set(True)
        context.view_layer.objects.active = new_obj

        # Report
        report_msg = f"Separated component '{new_name}'"
        if self.add_bone:
            report_msg += f" with bone '{bone_name}'"
            if self.parent_to_specific_bone and self.target_bone != 'NONE':
                report_msg += f" (parented to '{self.target_bone}')"
        elif self.parent_to_existing_bone and self.existing_target_bone != 'NONE':
            report_msg += f" skinned to existing bone '{self.existing_target_bone}'"
        if self.add_socket:
            report_msg += " and socket"

        self.report({'INFO'}, report_msg)
        return {'FINISHED'}

    # ============================================================================
    # UI
    # ============================================================================
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout

        layout.prop(self, "component_type")
        layout.prop(self, "custom_name")

        # Socket options
        layout.separator()
        box = layout.box()
        box.label(text="Socket Options", icon='EMPTY_DATA')
        box.prop(self, "add_socket")
        if self.add_socket:
            box.prop(self, "custom_socket_name")
            box.prop(self, "set_origin_to_socket")
            box.prop(self, "parent_socket_to_armature")

        # Bone options
        layout.separator()
        box = layout.box()
        box.label(text="Bone Options", icon='BONE_DATA')
        box.prop(self, "add_bone")
        if self.add_bone:
            box.prop(self, "custom_bone_name")
            box.prop(self, "auto_skinning")
            box.prop(self, "set_mesh_origin_to_bone")

            box.separator()
            box.label(text="Bone Direction:")
            box.prop(self, "use_world_direction")
            if self.use_world_direction:
                box.prop(self, "world_direction")
                box.prop(self, "preserve_angle")
            else:
                box.prop(self, "invert_bone_direction")

            box.separator()
            box.label(text="Bone Orientation:")
            box.prop(self, "bone_primary_axis")
            box.prop(self, "swap_yz_axes")
            box.prop(self, "align_roll_to_axis")

            box.separator()
            box.label(text="Bone Hierarchy:", icon='OUTLINER')
            box.prop(self, "parent_to_specific_bone")

            if self.parent_to_specific_bone:
                box.prop(self, "target_bone", text="", icon='BONE_DATA')
                if self.target_bone != 'NONE':
                    info_box = box.box()
                    info_box.label(text=f"New Bone -> {self.target_bone}", icon='INFO')
                    info_box.label(text="(Bone becomes child of selected bone)")
            else:
                info_box = box.box()
                info_box.label(text="Default: Bone -> v_body", icon='INFO')
        else:
            # No new bone - offer skinning to an existing bone
            box.separator()
            box.prop(self, "parent_to_existing_bone")
            if self.parent_to_existing_bone:
                box.prop(self, "existing_target_bone", text="", icon='BONE_DATA')
                if self.existing_target_bone != 'NONE':
                    info_box = box.box()
                    info_box.label(text=f"Mesh -> {self.existing_target_bone}", icon='INFO')
                    info_box.label(text="(Vertex group + Armature modifier)")
                else:
                    info_box = box.box()
                    info_box.label(text="Select a bone to skin to", icon='ERROR')


# ============================================================================
# PARENT BONES TO BONES OPERATOR
# ============================================================================
class ARVEHICLES_OT_parent_bones(bpy.types.Operator):
    bl_idname = "arvehicles.parent_bones"
    bl_label = "Parent Bones to Bones"
    bl_description = "Parent selected bones to a target bone"
    bl_options = {'REGISTER', 'UNDO'}

    def get_bone_items(self, context):
        items = [('NONE', "v_body (Default)", "Parent to v_body")]
        armature = context.active_object if context.active_object and context.active_object.type == 'ARMATURE' else None
        if armature:
            for bone in armature.data.bones:
                items.append((bone.name, bone.name, f"Parent to {bone.name}"))
        return items

    target_bone: bpy.props.EnumProperty(
        name="Parent To",
        description="Bone to parent selected bones to",
        items=get_bone_items
    )

    def execute(self, context):
        if context.active_object.type != 'ARMATURE':
            self.report({'ERROR'}, "Active object must be an armature")
            return {'CANCELLED'}

        armature = context.active_object

        if context.mode != 'EDIT_ARMATURE':
            self.report({'ERROR'}, "Must be in Armature Edit Mode")
            return {'CANCELLED'}

        selected_bones = [b for b in armature.data.edit_bones if b.select]

        if not selected_bones:
            self.report({'ERROR'}, "No bones selected")
            return {'CANCELLED'}

        target_name = 'v_body' if self.target_bone == 'NONE' else self.target_bone

        if target_name not in armature.data.edit_bones:
            self.report({'ERROR'}, f"Target bone '{target_name}' not found")
            return {'CANCELLED'}

        parent_bone = armature.data.edit_bones[target_name]

        parented_count = 0
        for bone in selected_bones:
            if bone.name != target_name:
                bone.parent = parent_bone
                bone.use_connect = False
                parented_count += 1

        self.report({'INFO'}, f"Parented {parented_count} bone(s) to '{target_name}'")
        return {'FINISHED'}

    def invoke(self, context, event):
        if context.active_object and context.active_object.type == 'ARMATURE':
            return context.window_manager.invoke_props_dialog(self)
        else:
            self.report({'ERROR'}, "Select an armature first")
            return {'CANCELLED'}

    def draw(self, context):
        layout = self.layout
        armature = context.active_object
        selected_bones = [b for b in armature.data.edit_bones if b.select] if context.mode == 'EDIT_ARMATURE' else []

        box = layout.box()
        box.label(text=f"Selected Bones: {len(selected_bones)}", icon='BONE_DATA')
        for bone in selected_bones[:5]:
            row = box.row()
            row.label(text=f"  - {bone.name}")
        if len(selected_bones) > 5:
            row = box.row()
            row.label(text=f"  ... and {len(selected_bones) - 5} more")

        layout.separator()
        layout.label(text="Parent To:", icon='OUTLINER')
        layout.prop(self, "target_bone", text="")


# ============================================================================
# ADD TO OBJECT OPERATOR
# ============================================================================
class ARVEHICLES_OT_add_to_object(bpy.types.Operator):
    bl_idname = "arvehicles.add_to_object"
    bl_label = "Add Bone/Socket to Object"
    bl_description = "Add bone and/or socket to already-separated mesh objects (object mode)"
    bl_options = {'REGISTER', 'UNDO'}

    component_type: bpy.props.EnumProperty(name="Component Type", items=VEHICLE_COMPONENT_TYPES, default='door')
    custom_name: bpy.props.StringProperty(
        name="Rename Object",
        default="",
        description="Optionally rename the object (only applied when a single object is selected)"
    )

    # Socket
    add_socket: bpy.props.BoolProperty(name="Add Socket", default=True)
    custom_socket_name: bpy.props.StringProperty(name="Custom Socket Name", default="")
    set_origin_to_socket: bpy.props.BoolProperty(name="Set Origin to Socket", default=True)
    parent_socket_to_armature: bpy.props.BoolProperty(name="Parent Socket to Armature", default=True)

    # Bone
    add_bone: bpy.props.BoolProperty(name="Add Bone", default=False)
    custom_bone_name: bpy.props.StringProperty(name="Custom Bone Name", default="")
    auto_skinning: bpy.props.BoolProperty(name="Auto Skinning", default=True)
    set_mesh_origin_to_bone: bpy.props.BoolProperty(name="Set Mesh Origin to Bone", default=True)
    invert_bone_direction: bpy.props.BoolProperty(name="Invert Bone Direction", default=False)

    world_direction: bpy.props.EnumProperty(
        name="Bone Direction",
        items=[
            ('POS_Y', "+Y (Forward)", ""),
            ('NEG_Y', "-Y (Backward)", ""),
            ('POS_X', "+X (Right)", ""),
            ('NEG_X', "-X (Left)", ""),
            ('POS_Z', "+Z (Up)", ""),
            ('NEG_Z', "-Z (Down)", ""),
        ],
        default='POS_Y'
    )
    bone_primary_axis: bpy.props.EnumProperty(
        name="Primary Rotation Axis",
        items=[
            ('Y', "Y Axis (Default)", ""),
            ('X', "X Axis", ""),
            ('Z', "Z Axis", ""),
        ],
        default='Y'
    )
    swap_yz_axes: bpy.props.BoolProperty(name="Swap Y<>Z Axes", default=False)
    align_roll_to_axis: bpy.props.EnumProperty(
        name="Align Roll To",
        items=[
            ('NONE',    "Auto (Roll=0)", ""),
            ('WORLD_Z', "World Z (Up)",  ""),
            ('WORLD_X', "World X",       ""),
            ('WORLD_Y', "World Y",       ""),
        ],
        default='WORLD_Z'
    )

    parent_to_specific_bone: bpy.props.BoolProperty(
        name="Parent Bone to Specific Bone",
        description="Make the new bone a child of a specific existing bone",
        default=False
    )

    def get_available_bones(self, context):
        items = [('NONE', "v_body (Default)", "Parent to v_body or v_root")]
        for obj in bpy.data.objects:
            if obj.type == 'ARMATURE':
                for bone in obj.data.bones:
                    items.append((bone.name, bone.name, f"Parent new bone to {bone.name}"))
                break
        return items

    target_bone: bpy.props.EnumProperty(
        name="Parent Bone",
        description="Existing bone to parent the new bone to",
        items=get_available_bones
    )

    parent_to_existing_bone: bpy.props.BoolProperty(
        name="Skin to Existing Bone",
        description="Assign all vertices to an existing bone instead of creating a new one",
        default=False
    )

    def get_existing_bones(self, context):
        items = [('NONE', "Select Bone", "No bone selected")]
        for obj in bpy.data.objects:
            if obj.type == 'ARMATURE':
                for bone in obj.data.bones:
                    items.append((bone.name, bone.name, f"Skin mesh to {bone.name}"))
                break
        return items

    existing_target_bone: bpy.props.EnumProperty(
        name="Target Bone",
        description="Existing bone to skin the object to",
        items=get_existing_bones
    )

    def _get_socket_type_for_component(self, component_type):
        mapping = {
            'window': 'window', 'door': 'door', 'hood': 'hood', 'trunk': 'trunk',
            'wheel': 'wheel', 'light': 'light', 'mirror': 'mirror', 'antenna': 'antenna',
            'hatch': 'hatch', 'panel': 'panel', 'seat': 'seat', 'dashboard': 'dashboard',
            'steering_wheel': 'steering_wheel', 'gear_shifter': 'gear_shifter',
            'handbrake': 'handbrake', 'pedal': 'pedal', 'engine': 'engine',
            'exhaust': 'exhaust', 'suspension': 'suspension', 'rotor': 'rotor',
            'landing_gear': 'landing_gear', 'fuel_tank': 'fuel_tank',
            'battery': 'battery', 'radiator': 'radiator',
        }
        return mapping.get(component_type, 'custom')

    def _get_bone_type_for_component(self, component_type):
        mapping = {
            'door': 'v_door_left', 'hood': 'v_hood', 'trunk': 'v_trunk',
            'wheel': 'v_wheel_1', 'steering_wheel': 'v_steering_wheel',
            'gear_shifter': 'v_gearshift', 'handbrake': 'v_handbrake',
            'pedal': 'v_pedal_brake', 'exhaust': 'v_exhaust',
            'suspension': 'v_suspension1', 'rotor': 'v_rotor',
            'landing_gear': 'v_landing_gear', 'antenna': 'v_antenna',
            'mirror': 'v_mirror_left', 'dashboard': 'v_dashboard_arm',
        }
        return mapping.get(component_type, 'custom')

    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'ERROR'}, "Must be in Object Mode")
            return {'CANCELLED'}

        mesh_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not mesh_objects:
            self.report({'ERROR'}, "No mesh objects selected")
            return {'CANCELLED'}

        armature = next((obj for obj in bpy.data.objects if obj.type == 'ARMATURE'), None)

        direction_map = {
            'POS_Y': Vector((0,  1, 0)),
            'NEG_Y': Vector((0, -1, 0)),
            'POS_X': Vector(( 1, 0, 0)),
            'NEG_X': Vector((-1, 0, 0)),
            'POS_Z': Vector((0, 0,  1)),
            'NEG_Z': Vector((0, 0, -1)),
        }
        roll_map = {
            'WORLD_Z': Vector((0, 0, 1)),
            'WORLD_X': Vector((1, 0, 0)),
            'WORLD_Y': Vector((0, 1, 0)),
        }

        socket_type = self._get_socket_type_for_component(self.component_type)
        bone_type   = self._get_bone_type_for_component(self.component_type)

        processed = 0
        for obj in mesh_objects:
            # Bounding box center in world space
            world_center = sum(
                (obj.matrix_world @ Vector(corner) for corner in obj.bound_box),
                Vector()
            ) / 8

            if self.custom_name and len(mesh_objects) == 1:
                obj.name = self.custom_name
            obj["component_type"] = self.component_type

            # Build direction vector
            bone_dir = direction_map[self.world_direction].copy()
            if self.invert_bone_direction:
                bone_dir = -bone_dir
            if self.bone_primary_axis == 'X':
                bone_dir = Vector((bone_dir.y, bone_dir.z, bone_dir.x))
            elif self.bone_primary_axis == 'Z':
                bone_dir = Vector((bone_dir.z, bone_dir.x, bone_dir.y))
            if self.swap_yz_axes:
                bone_dir = Vector((bone_dir.x, bone_dir.z, bone_dir.y))
            bone_dir.normalize()

            bone_name = None

            # ----------------------------------------------------------------
            # BONE CREATION
            # ----------------------------------------------------------------
            if self.add_bone:
                if not armature:
                    arm_data = bpy.data.armatures.new("Armature")
                    armature = bpy.data.objects.new("Armature", arm_data)
                    context.collection.objects.link(armature)
                    context.view_layer.objects.active = armature
                    bpy.ops.object.mode_set(mode='EDIT')
                    rb = arm_data.edit_bones.new('v_root')
                    rb.head = (0, 0, 0); rb.tail = (0, 0.2, 0)
                    bb = arm_data.edit_bones.new('v_body')
                    bb.head = (0, 0, 0.35); bb.tail = (0, 0.2, 0.35)
                    bb.parent = rb
                    bpy.ops.object.mode_set(mode='OBJECT')

                if self.custom_bone_name:
                    bone_name = self.custom_bone_name
                    if not bone_name.startswith('v_'):
                        bone_name = 'v_' + bone_name
                elif bone_type == 'custom':
                    bone_name = f"v_{obj.name.lower().replace(' ', '_')}"
                else:
                    bone_name = bone_type
                    counter = 1
                    base = bone_name
                    while bone_name in armature.data.bones:
                        bone_name = f"{base}_{counter:02d}"
                        counter += 1

                context.view_layer.objects.active = armature
                bpy.ops.object.mode_set(mode='EDIT')
                bone = armature.data.edit_bones.new(bone_name)

                if self.parent_to_specific_bone and self.target_bone != 'NONE':
                    if self.target_bone in armature.data.edit_bones:
                        bone.parent = armature.data.edit_bones[self.target_bone]
                        bone.use_connect = False
                elif 'v_body' in armature.data.edit_bones:
                    bone.parent = armature.data.edit_bones['v_body']
                elif 'v_root' in armature.data.edit_bones:
                    bone.parent = armature.data.edit_bones['v_root']

                bone.head = world_center
                bone.tail = world_center + bone_dir * 0.2
                if self.align_roll_to_axis in roll_map:
                    bone.align_roll(roll_map[self.align_roll_to_axis])
                else:
                    bone.roll = 0.0

                bpy.ops.object.mode_set(mode='OBJECT')

                if self.set_mesh_origin_to_bone:
                    bpy.ops.object.select_all(action='DESELECT')
                    obj.select_set(True)
                    context.view_layer.objects.active = obj
                    saved_cursor = context.scene.cursor.location.copy()
                    context.scene.cursor.location = world_center
                    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
                    context.scene.cursor.location = saved_cursor

                if self.auto_skinning:
                    bpy.ops.object.select_all(action='DESELECT')
                    obj.select_set(True)
                    context.view_layer.objects.active = obj

                    for mod in list(obj.modifiers):
                        if mod.type == 'ARMATURE':
                            obj.modifiers.remove(mod)
                    obj.vertex_groups.clear()

                    vg = obj.vertex_groups.new(name=bone_name)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.mesh.select_all(action='SELECT')
                    obj.vertex_groups.active = vg
                    bpy.ops.object.vertex_group_assign()
                    bpy.ops.object.mode_set(mode='OBJECT')

                    arm_mod = obj.modifiers.new(name="Armature", type='ARMATURE')
                    arm_mod.object = armature

            # ----------------------------------------------------------------
            # SKIN TO EXISTING BONE (no new bone)
            # ----------------------------------------------------------------
            elif self.parent_to_existing_bone and self.existing_target_bone != 'NONE':
                if armature and self.existing_target_bone in armature.data.bones:
                    bpy.ops.object.select_all(action='DESELECT')
                    obj.select_set(True)
                    context.view_layer.objects.active = obj

                    for mod in list(obj.modifiers):
                        if mod.type == 'ARMATURE':
                            obj.modifiers.remove(mod)
                    obj.vertex_groups.clear()

                    vg = obj.vertex_groups.new(name=self.existing_target_bone)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.mesh.select_all(action='SELECT')
                    obj.vertex_groups.active = vg
                    bpy.ops.object.vertex_group_assign()
                    bpy.ops.object.mode_set(mode='OBJECT')

                    arm_mod = obj.modifiers.new(name="Armature", type='ARMATURE')
                    arm_mod.object = armature
                else:
                    self.report({'WARNING'}, f"Bone '{self.existing_target_bone}' not found")

            # ----------------------------------------------------------------
            # SOCKET CREATION
            # ----------------------------------------------------------------
            if self.add_socket:
                if self.custom_socket_name:
                    socket_name = self.custom_socket_name
                elif socket_type == 'custom':
                    socket_name = f"Socket_{obj.name.replace(' ', '_')}"
                else:
                    socket_name = f"Socket_{socket_type.replace('_', ' ').title().replace(' ', '_')}"
                    existing = [o for o in bpy.data.objects if socket_name in o.name]
                    if existing:
                        socket_name = f"{socket_name}_{len(existing) + 1:02d}"

                sock = bpy.data.objects.new(socket_name, None)
                sock.empty_display_type = 'ARROWS'
                sock.empty_display_size = 0.15
                sock.location = world_center
                context.collection.objects.link(sock)
                sock["socket_type"]   = socket_type
                sock["attached_part"] = obj.name
                sock["vehicle_part"]  = "attachment_point"

                if armature and self.parent_socket_to_armature:
                    sock.parent = armature
                    sock.parent_type = 'OBJECT'

                if self.set_origin_to_socket:
                    bpy.ops.object.select_all(action='DESELECT')
                    obj.select_set(True)
                    context.view_layer.objects.active = obj
                    saved_cursor = context.scene.cursor.location.copy()
                    context.scene.cursor.location = sock.location
                    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
                    context.scene.cursor.location = saved_cursor

            processed += 1

        # Restore selection
        bpy.ops.object.select_all(action='DESELECT')
        for obj in mesh_objects:
            obj.select_set(True)
        if mesh_objects:
            context.view_layer.objects.active = mesh_objects[0]

        self.report({'INFO'}, f"Processed {processed} object(s)")
        return {'FINISHED'}

    def invoke(self, context, event):
        if context.mode != 'OBJECT':
            self.report({'ERROR'}, "Must be in Object Mode")
            return {'CANCELLED'}
        mesh_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not mesh_objects:
            self.report({'ERROR'}, "No mesh objects selected")
            return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        mesh_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']

        box = layout.box()
        box.label(text=f"Selected Objects: {len(mesh_objects)}", icon='OBJECT_DATA')
        for obj in mesh_objects[:4]:
            box.label(text=f"  - {obj.name}")
        if len(mesh_objects) > 4:
            box.label(text=f"  ... and {len(mesh_objects) - 4} more")

        layout.prop(self, "component_type")
        if len(mesh_objects) == 1:
            layout.prop(self, "custom_name")

        # Socket options
        layout.separator()
        box = layout.box()
        box.label(text="Socket Options", icon='EMPTY_DATA')
        box.prop(self, "add_socket")
        if self.add_socket:
            box.prop(self, "custom_socket_name")
            box.prop(self, "set_origin_to_socket")
            box.prop(self, "parent_socket_to_armature")

        # Bone options
        layout.separator()
        box = layout.box()
        box.label(text="Bone Options", icon='BONE_DATA')
        box.prop(self, "add_bone")
        if self.add_bone:
            box.prop(self, "custom_bone_name")
            box.prop(self, "auto_skinning")
            box.prop(self, "set_mesh_origin_to_bone")

            box.separator()
            box.label(text="Bone Direction:")
            box.prop(self, "world_direction")
            box.prop(self, "invert_bone_direction")

            box.separator()
            box.label(text="Bone Orientation:")
            box.prop(self, "bone_primary_axis")
            box.prop(self, "swap_yz_axes")
            box.prop(self, "align_roll_to_axis")

            box.separator()
            box.label(text="Bone Hierarchy:", icon='OUTLINER')
            box.prop(self, "parent_to_specific_bone")
            if self.parent_to_specific_bone:
                box.prop(self, "target_bone", text="", icon='BONE_DATA')
                if self.target_bone != 'NONE':
                    ib = box.box()
                    ib.label(text=f"New Bone -> {self.target_bone}", icon='INFO')
            else:
                ib = box.box()
                ib.label(text="Default: Bone -> v_body", icon='INFO')
        else:
            box.separator()
            box.prop(self, "parent_to_existing_bone")
            if self.parent_to_existing_bone:
                box.prop(self, "existing_target_bone", text="", icon='BONE_DATA')
                if self.existing_target_bone != 'NONE':
                    ib = box.box()
                    ib.label(text=f"Mesh -> {self.existing_target_bone}", icon='INFO')
                    ib.label(text="(Vertex group + Armature modifier)")
                else:
                    ib = box.box()
                    ib.label(text="Select a bone to skin to", icon='ERROR')
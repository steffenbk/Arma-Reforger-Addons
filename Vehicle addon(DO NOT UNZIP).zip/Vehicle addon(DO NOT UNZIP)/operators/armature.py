# ============================================================================
# PART 1: IMPORTS AND CLASS DEFINITION
# ============================================================================
import bpy
from ..constants import VEHICLE_BONE_TYPES
from mathutils import Vector

class ARVEHICLES_OT_create_armature(bpy.types.Operator):
    bl_idname = "arvehicles.create_armature"
    bl_label = "Create Vehicle Armature"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Create vehicle armature with v_root and v_body, and setup selected mesh as body"
    
    # ============================================================================
    # PART 2: EXECUTE METHOD - ARMATURE CREATION
    # ============================================================================
    def execute(self, context):
        # Get selected mesh (the body)
        body_mesh = None
        if context.active_object and context.active_object.type == 'MESH':
            body_mesh = context.active_object
        
        # Check if armature already exists
        existing_armature = None
        for obj in bpy.data.objects:
            if obj.type == 'ARMATURE' and obj.name in ["Armature", "VehicleArmature"]:
                existing_armature = obj
                break
        
        if existing_armature:
            self.report({'INFO'}, f"Vehicle armature '{existing_armature.name}' already exists")
            context.view_layer.objects.active = existing_armature
            return {'FINISHED'}
        
        # Create armature - keep name as "Armature" per Arma standards
        armature_data = bpy.data.armatures.new("Armature")
        armature_obj = bpy.data.objects.new("Armature", armature_data)
        context.collection.objects.link(armature_obj)
        
        # Set armature at world origin with proper scale (required by Arma)
        armature_obj.location = (0, 0, 0)
        armature_obj.rotation_euler = (0, 0, 0)
        armature_obj.scale = (1.0, 1.0, 1.0)
        
# ============================================================================
# ============================================================================
        # PART 3: BONE CREATION - V_ROOT AND V_BODY
        # ============================================================================
        context.view_layer.objects.active = armature_obj
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Create v_root bone - stays at world origin (Arma standard)
        root_bone = armature_data.edit_bones.new('v_root')
        root_bone.head = (0, 0, 0)
        root_bone.tail = (0, 0.2, 0)
        root_bone.roll = 0.0
        
        # Create v_body bone - ALWAYS at standard 0.35m offset from v_root on Z axis
        # This matches Arma Reforger vehicle skeleton conventions
        # The distance between v_root and v_body is consistent across all vehicles
        body_bone = armature_data.edit_bones.new('v_body')
        body_bone.head = (0, 0, 0.35)  # 0.35m UP from v_root
        body_bone.tail = (0, 0.2, 0.35)  # Pointing forward along Y, at Z=0.35
        body_bone.roll = 0.0
        body_bone.parent = root_bone
        
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # ============================================================================
        # PART 4: ARMATURE DISPLAY SETTINGS
        # ============================================================================
        # Set display properties for easier bone visibility
        armature_data.display_type = 'OCTAHEDRAL'
        armature_data.show_names = True
        armature_obj.show_in_front = True
        
        # ============================================================================
        # PART 5: BODY MESH SETUP AND SKINNING
        # ============================================================================
        # Setup body mesh if one was selected
        if body_mesh:
            # Create v_body vertex group
            vg_body = body_mesh.vertex_groups.get('v_body')
            if not vg_body:
                vg_body = body_mesh.vertex_groups.new(name='v_body')
            
            # Weight all vertices to v_body
            all_verts = [v.index for v in body_mesh.data.vertices]
            vg_body.add(all_verts, 1.0, 'REPLACE')
            
            # Add armature modifier
            if not any(mod.type == 'ARMATURE' for mod in body_mesh.modifiers):
                arm_mod = body_mesh.modifiers.new(name="Armature", type='ARMATURE')
                arm_mod.object = armature_obj
            
            # Parent body mesh to armature - preserve world position
            world_matrix = body_mesh.matrix_world.copy()
            body_mesh.parent = armature_obj
            body_mesh.parent_type = 'ARMATURE'
            body_mesh.matrix_world = world_matrix
            
            self.report({'INFO'}, f"Created armature and setup '{body_mesh.name}' as vehicle body")
        else:
            self.report({'INFO'}, "Created armature (no mesh selected for body)")
        
        return {'FINISHED'}

# ============================================================================
# PART 6: CREATE BONE OPERATOR CLASS
# ============================================================================
class ARVEHICLES_OT_create_bone(bpy.types.Operator):
    bl_idname = "arvehicles.create_bone"
    bl_label = "Add Bone"
    bl_options = {'REGISTER', 'UNDO'}
    
    bone_type: bpy.props.EnumProperty(name="Bone Type", items=VEHICLE_BONE_TYPES, default='v_door_left')
    custom_bone_name: bpy.props.StringProperty(name="Bone Name", default="custom")
    
    # ============================================================================
    # PART 7: EXECUTE METHOD - BONE CREATION
    # ============================================================================
    def execute(self, context):
        armature = None
        for obj in bpy.data.objects:
            if obj.type == 'ARMATURE':
                armature = obj
                break
        
        if not armature:
            self.report({'ERROR'}, "No vehicle armature found")
            return {'CANCELLED'}
        
        context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode='EDIT')
        
        bone_length = 0.2
        
        # ============================================================================
        # PART 8: BONE NAMING AND DUPLICATE HANDLING
        # ============================================================================
        if self.bone_type == 'custom':
            bone_name = self.custom_bone_name
            if not bone_name.startswith('v_'):
                bone_name = 'v_' + bone_name
        else:
            bone_name = self.bone_type
        
        if bone_name in armature.data.edit_bones:
            if bone_name in ['v_root', 'v_body']:
                self.report({'INFO'}, f"{bone_name} already exists")
                bpy.ops.object.mode_set(mode='OBJECT')
                return {'FINISHED'}
            else:
                base_name = bone_name
                counter = 1
                while bone_name in armature.data.edit_bones:
                    bone_name = f"{base_name}_{counter:02d}"
                    counter += 1
        
        # ============================================================================
        # PART 9: BONE PARENTING SETUP
        # ============================================================================
        # Parent to v_body if it exists, otherwise v_root
        parent_bone = None
        if self.bone_type not in ['v_root', 'v_body']:
            if 'v_body' in armature.data.edit_bones:
                parent_bone = armature.data.edit_bones['v_body']
            elif 'v_root' in armature.data.edit_bones:
                parent_bone = armature.data.edit_bones['v_root']
        elif self.bone_type == 'v_body' and 'v_root' in armature.data.edit_bones:
            parent_bone = armature.data.edit_bones['v_root']
        
        bone = armature.data.edit_bones.new(bone_name)
        bone.roll = 0.0
        if parent_bone:
            bone.parent = parent_bone
        
        # ============================================================================
        # PART 10: BONE POSITIONING BY TYPE
        # ============================================================================
        if self.bone_type == 'v_root':
            bone.head = (0, 0, 0)
            bone.tail = (0, bone_length, 0)
        elif self.bone_type == 'v_body':
            bone.head = (0, 0.35, 0)
            bone.tail = (0, 0.35 + bone_length, 0)
        elif 'door_left' in self.bone_type:
            bone.head = (0.8, 0.2, 0.8)
            bone.tail = (0.8, 0.2 + bone_length, 0.8)
        elif 'door_right' in self.bone_type:
            bone.head = (-0.8, 0.2, 0.8)
            bone.tail = (-0.8, 0.2 + bone_length, 0.8)
        elif 'wheel' in self.bone_type:
            bone.head = (0.7, 1.0, 0.3)
            bone.tail = (0.7, 1.0 + bone_length, 0.3)
        elif self.bone_type == 'v_hood':
            bone.head = (0, 1.5, 1.0)
            bone.tail = (0, 1.5 + bone_length, 1.0)
        elif self.bone_type == 'v_trunk':
            bone.head = (0, -1.5, 1.0)
            bone.tail = (0, -1.5 + bone_length, 1.0)
        elif self.bone_type == 'v_steeringwheel':
            bone.head = (0.3, 0.5, 0.9)
            bone.tail = (0.3, 0.5 + bone_length, 0.9)
        else:
            bone.head = (0, 0, 0.5)
            bone.tail = (0, bone_length, 0.5)
        
        bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, f"Created {bone_name} bone")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        if self.bone_type == 'custom':
            return context.window_manager.invoke_props_dialog(self)
        else:
            return self.execute(context)

# ============================================================================
# ALIGN SELECTED BONES DIRECTION OPERATOR
# ============================================================================
class ARVEHICLES_OT_align_bones_direction(bpy.types.Operator):
    bl_idname = "arvehicles.align_bones_direction"
    bl_label = "Align Bone Directions"
    bl_description = "Force selected bones to point in a specific world direction, preserving head positions"
    bl_options = {'REGISTER', 'UNDO'}

    world_direction: bpy.props.EnumProperty(
        name="Direction",
        description="World direction all selected bones will point toward",
        items=[
            ('POS_Y', "+Y (Forward)",  "Point toward +Y"),
            ('NEG_Y', "-Y (Backward)", "Point toward -Y"),
            ('POS_X', "+X (Right)",    "Point toward +X"),
            ('NEG_X', "-X (Left)",     "Point toward -X"),
            ('POS_Z', "+Z (Up)",       "Point toward +Z"),
            ('NEG_Z', "-Z (Down)",     "Point toward -Z"),
        ],
        default='POS_Y'
    )

    invert_direction: bpy.props.BoolProperty(
        name="Invert Direction",
        description="Flip the chosen direction",
        default=False
    )

    bone_primary_axis: bpy.props.EnumProperty(
        name="Primary Rotation Axis",
        description="Remap which local axis the direction is applied to",
        items=[
            ('Y', "Y Axis (Default)", ""),
            ('X', "X Axis",           ""),
            ('Z', "Z Axis",           ""),
        ],
        default='Y'
    )

    swap_yz_axes: bpy.props.BoolProperty(
        name="Swap Y↔Z Axes",
        description="Swap Y and Z components of the direction vector",
        default=False
    )

    align_roll_to_axis: bpy.props.EnumProperty(
        name="Align Roll To",
        description="Which world axis to align the bone roll to",
        items=[
            ('NONE',    "Auto (Roll=0)",  "Set roll to 0"),
            ('WORLD_Z', "World Z (Up)",   ""),
            ('WORLD_X', "World X",        ""),
            ('WORLD_Y', "World Y",        ""),
        ],
        default='WORLD_Z'
    )

    preserve_length: bpy.props.BoolProperty(
        name="Preserve Bone Length",
        description="Keep each bone's original length; uncheck to use a fixed length",
        default=True
    )

    fixed_length: bpy.props.FloatProperty(
        name="Fixed Length",
        description="Length to use when Preserve Bone Length is off",
        default=0.2,
        min=0.001,
        soft_max=2.0,
        unit='LENGTH'
    )

    def execute(self, context):
        if context.mode != 'EDIT_ARMATURE':
            self.report({'ERROR'}, "Must be in Armature Edit Mode")
            return {'CANCELLED'}

        armature = context.active_object
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "Active object must be an armature")
            return {'CANCELLED'}

        selected_bones = [b for b in armature.data.edit_bones if b.select]
        if not selected_bones:
            self.report({'ERROR'}, "No bones selected")
            return {'CANCELLED'}

        # Build base direction vector
        direction_map = {
            'POS_Y': Vector((0,  1, 0)),
            'NEG_Y': Vector((0, -1, 0)),
            'POS_X': Vector(( 1, 0, 0)),
            'NEG_X': Vector((-1, 0, 0)),
            'POS_Z': Vector((0, 0,  1)),
            'NEG_Z': Vector((0, 0, -1)),
        }
        direction = direction_map[self.world_direction].copy()

        if self.invert_direction:
            direction = -direction

        # Axis remapping
        if self.bone_primary_axis == 'X':
            direction = Vector((direction.y, direction.z, direction.x))
        elif self.bone_primary_axis == 'Z':
            direction = Vector((direction.z, direction.x, direction.y))

        if self.swap_yz_axes:
            direction = Vector((direction.x, direction.z, direction.y))

        direction.normalize()

        roll_axis_map = {
            'WORLD_Z': Vector((0, 0, 1)),
            'WORLD_X': Vector((1, 0, 0)),
            'WORLD_Y': Vector((0, 1, 0)),
        }

        count = 0
        for bone in selected_bones:
            length = bone.length if self.preserve_length else self.fixed_length
            if length < 0.001:
                length = 0.2  # Safety floor for zero-length bones

            bone.tail = bone.head + direction * length

            if self.align_roll_to_axis in roll_axis_map:
                bone.align_roll(roll_axis_map[self.align_roll_to_axis])
            else:
                bone.roll = 0.0

            count += 1

        self.report({'INFO'}, f"Aligned {count} bone(s) to {self.world_direction}")
        return {'FINISHED'}

    def invoke(self, context, event):
        if context.mode != 'EDIT_ARMATURE':
            self.report({'ERROR'}, "Must be in Armature Edit Mode")
            return {'CANCELLED'}
        selected = [b for b in context.active_object.data.edit_bones if b.select]
        if not selected:
            self.report({'ERROR'}, "No bones selected")
            return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        layout = self.layout
        armature = context.active_object
        selected = [b for b in armature.data.edit_bones if b.select] if context.mode == 'EDIT_ARMATURE' else []

        box = layout.box()
        box.label(text=f"Selected Bones: {len(selected)}", icon='BONE_DATA')
        for bone in selected[:6]:
            box.label(text=f"  • {bone.name}")
        if len(selected) > 6:
            box.label(text=f"  ... and {len(selected) - 6} more")

        layout.separator()

        box = layout.box()
        box.label(text="Direction", icon='ORIENTATION_GLOBAL')
        box.prop(self, "world_direction")
        box.prop(self, "invert_direction")

        layout.separator()

        box = layout.box()
        box.label(text="Orientation", icon='DRIVER_ROTATIONAL_DIFFERENCE')
        box.prop(self, "bone_primary_axis")
        box.prop(self, "swap_yz_axes")
        box.prop(self, "align_roll_to_axis")

        layout.separator()

        box = layout.box()
        box.label(text="Length", icon='DRIVER_DISTANCE')
        box.prop(self, "preserve_length")
        if not self.preserve_length:
            box.prop(self, "fixed_length")
